apt-get install golang -y
apt-get install perl -y
apt-get install python3 -y
apt-get install python2 -y
apt-get install python3-pip -y
apt-get install nodejs -y
apt-get install npm -y

npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i cloudflare-bypasser